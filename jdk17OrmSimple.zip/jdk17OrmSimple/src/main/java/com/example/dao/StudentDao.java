package com.example.dao;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.example.entities.Student;


public class StudentDao {

private HibernateTemplate hibernateTemplate;

@Transactional
public int insert(Student student) {
    
    Integer r=(Integer)hibernateTemplate.save(student);
    return r;
}

public HibernateTemplate getHibernateTemplate() {
    return hibernateTemplate;
}

public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
    this.hibernateTemplate = hibernateTemplate;
}

public StudentDao(HibernateTemplate hibernateTemplate) {
    super();
    this.hibernateTemplate = hibernateTemplate;
}
public StudentDao() {


}}