package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.dao.StudentDao;
import com.example.entities.Student;

public class App {
	
	
    public static void main(String[] args) {
    
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml") ;
        
            StudentDao studentDao = context.getBean("studentDao", StudentDao.class);

            Student student = new Student(12, "Aalam", "Dubai");

          
                int result = studentDao.insert(student);
                System.out.println("Done. Rows affected: " + result);
            } }
            
            
            
            
            
            
